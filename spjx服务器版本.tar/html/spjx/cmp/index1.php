<?php
$fname='http://'.$_SERVER['SERVER_NAME'].$_SERVER["SCRIPT_NAME"];
$app='http://deng.lhkjw.com/';$app='/api/';
$data=$_SERVER['QUERY_STRING'];parse_str($data);$nx=explode('=',$data);
for($i=1;$i<count($nx);$i++){if($i==count($nx)-1){$a.=$nx[$i];}else{$a.=$nx[$i].'=';}}
$api=$_REQUEST['apikeyurl'];if($api&&$api!=''){
	header("Content-Type: text/xml; charset=utf-8");
	$xml.='<list><m type="merge" src="{apid}'.$api.'_1" stream="true" label="高清" />';
	$xml.='<m type="merge" src="{apid}'.$api.'_0" stream="true" label="流畅" />';
	$xml.='<m type="merge" src="{apid}'.$api.'_2" stream="true" label="超清" /></list>';
echo $xml;exit;}
$api=$_REQUEST['apikey'];if($api&&$api!=''){
	header("Content-Type: text/xml; charset=utf-8");
	$vid=explode('.',$api);$vsid=explode('_',$vid[0]);
	$xml.='<list><m type="merge" src="{apid}'.$vsid[0].'_1.'.$vid[1].'" stream="true" label="高清" />';
	$xml.='<m type="merge" src="{apid}'.$vsid[0].'_0.'.$vid[1].'" stream="true" label="流畅" />';
	$xml.='<m type="merge" src="{apid}'.$vsid[0].'_2.'.$vid[1].'" stream="true" label="超清" /></list>';
echo $xml;exit;}
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>隆虎科技☆护眼灯☆云播</title>
<meta name="keywords" content="隆虎科技,隆虎科技网,网络视频播放器">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<style type="text/css">
html, body {height:100%; margin:0; padding:0; overflow:hidden; text-align:center; background:#181818;}
</style></head>
<body oncontextmenu=self.event.returnValue=false>
<script type="text/javascript" src="cmp.js"></script>';
$jsapi.='<script type="text/javascript">'."\n".'var flashvars={skin:"mv.swf",apid:"';
if($id&&$id!=''){$jsapi.=$app.'?cmpid=",lists:"'.$fname.'?apikey='.$a;
}elseif($cmpid&&$cmpid!=''){$jsapi.=$app.'?cmpid=",lists:"'.$fname.'?apikey='.$a;
}else{$jsapi.=$app.'?cmp=",lists:"'.$fname.'?apikeyurl='.$a;}
$jsapi.='",auto_play:"1",plugins:"merge.swf",type:"merge"};'."\n";
$jsapi.='CMP.write("cmp", "100%", "100%", "player.swf",flashvars, {});';
$jsapi.='</script>';
echo $jsapi;
echo '</body></html>';
?>