<?php
error_reporting(0);
header('Content-type:text/html;charset=utf-8');
$re=$_SERVER['HTTP_REFERER'];if(!$re)$re='http://bbs.lhkjw.com';
?><!DOCTYPE html><html><head><meta charset="utf-8"><title>灯哥解析-万能整合</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="renderer" content="webkit">
<meta http-equiv="Cache-Control" content="no-siteapp"/>
<style type="text/css">*{margin:0px;padding:0px;}html{height:100%;margin:0;}
body{height:100%;margin:0;}</style></head>
<body><div id="a1" style="width:100%; height:100%; background-color:#000;"></div>
<script type="text/javascript" src="player.js" charset="utf-8"></script>
<script type="text/javascript"><?php
	$baseUrl=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!='off')?'https://':'http://';
	$fself=$_SERVER["PHP_SELF"];$url=$baseUrl.$_SERVER['HTTP_HOST'].$fself;
	$arr=explode('/',$url);array_pop($arr);array_pop($arr);$api=implode('/', $arr);
	if(file_exists('api/index.php'))$file='';else $file='deng.php';
	$api.='/api/'.$file.'?ckid=';echo "var app='".$api."',";
	$pid=$_REQUEST["pid"];if(!$pid)$pid='XODAyOTkwNzYw.youku'; echo "pid='".$pid."'";?>;
var flashvars={f:app+pid,s:2,p:1,c:0,my_url:encodeURIComponent('<?php echo $re;?>')}
var params={bgcolor:'#FFF',allowFullScreen:true,allowScriptAccess:'always',wmode:'transparent'};
var video=[app+pid+'&mobile=1->ajax/get/utf-8'];
CKobject.embed('player.swf','a1','ckplayer_a1','100%','100%',false,flashvars,video,params);
</script></body></html>